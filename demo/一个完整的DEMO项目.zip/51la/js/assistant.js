var J = Jx();
var E = J.event;
var D = J.dom;
var H = J.http;
var S = J.string;
var C = J.cookie;