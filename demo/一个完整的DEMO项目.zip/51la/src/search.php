﻿<?php
class Search{
	//一下子检查所有的数据
	public static function check($urlArr)
	{
		$config = require('config.php');
		$rule = $config['rule'];
		$arr = array();
		$count = count($urlArr);
		for ($i=0; $i < $count; $i++) { 
			$qarr = Util::parseURLQuery($urlArr[$i]);
			$dataArr = self::getData($urlArr[$i]);
			if(!count($dataArr))continue;
			$kw = self::getKeyword($dataArr['field'],$qarr);
			if(!$kw)continue;
			$surl = $dataArr['searcher'].$kw;
			$html = file_get_contents($surl);
			$bool = Util::arrayInStr($rule,$html);
			$arr[$i]['keyword'] = Util::safeEncoding(urldecode($kw));
			$arr[$i]['name'] = $dataArr['name'];
			$arr[$i]['exist'] = $bool;
		}
		return $arr;		
	}
	//单个单个数据的检查
	public static function checkOne($url)
	{
		$config = require('config.php');
		$rule = $config['rule'];
		$arr = array();
		$qarr = Util::parseURLQuery($url);
		$dataArr = self::getData($url);
		if(!count($dataArr))continue;
		$kw = self::getKeyword($dataArr['field'],$qarr);
		if(!$kw)continue;
		$surl = $dataArr['searcher'].$kw;
		$html = @file_get_contents($surl);
		$bool = Util::arrayInStr($rule,$html);
		$arr['keyword'] = Util::safeEncoding(urldecode($kw));
		$arr['name'] = $dataArr['name'];
		$arr['exist'] = $bool;
		return $arr;
	}
	private static function getData($url)
	{
		$arr = array();
		$data = require('data.php');
		foreach ($data as $key => $value) {
			if(stristr($url, $key))
			{
				$arr = $value;
				break;
			}
		}
		return $arr;
	}
	private static function getKeyword($field,$qarr)
	{
		$kw = '';
		if(is_array($field))
		{
			foreach ($field as $v) {
				if(isset($qarr[$v]))
				{
					$kw = $qarr[$v];
				}
			}
		}else if(isset($qarr[$field]))
		{
			$kw = $qarr[$field];
		}
		return $kw;
	}
};