<?php
class Login{
	private $config;
	private $loginURL;
	private $http;
	public function Login()
	{
		$this->config = require('config.php');
	    $this->loginURL = 'http://www.51.la/report/0_help.asp?uname=&upass=&id='.$this->config['id'].'&t=guanlogin&pass='.$this->config['password'];
		$this->http = new Http();
		$this->loginUser();
	}
	private function loginUser()
	{
		 return  $this->http->get($this->loginURL);
	}
	public function getTxt()
	{
		$urlArr = array();
		date_default_timezone_set('PRC');
		//获取6天前的时间戳
		$day7 = mktime(0,0,0,date("m"),date("d")-6,date("Y"));
		$rt = $this->http->get('http://www.51.la/report/3_Keyword.asp?id='.$this->config['id'].'&ord=k_ci&d1='.date('Y-m-d',$day7).'&d2='.date('Y-m-d'));
		$Q = new QueryList($rt,array('txt_down_url'=>array('.bodys_zw:eq(0)>div:last>a:eq(0)','href')),'#bodys','',false);

		if(count($Q->jsonArr))
		{
			$downURL = 'http://www.51.la/report/'.$Q->jsonArr[0]['txt_down_url'];
			$txt = $this->http->get($downURL);
			$urlArr = Util::getAllURL($txt);
		}
		return $urlArr;
	}
}