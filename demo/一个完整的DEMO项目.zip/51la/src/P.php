<?php
class P{
	public static function show()
	{
		$arr = Search::checkOne('http://www.so.com/s?ie=utf-8&src=hao_360so&q=%E5%85%A8%E8%AE%AF%E7%BD%91%E6%96%B02');
		print_r($arr);
		die();
		$hj = new Login();
		$arr = $hj->getTxt();
		print_r($arr);die();
		$rtarr = Search::check($arr);
		echo<<<str
		<table>
			<thead>
				<th>关键词</th>
				<th>搜索引擎</th>
			</thead>
			<tbody>
str;
		foreach ($rtarr as $item) {
			// echo '<tr '.($item['exist']?'style="background-color: red"':'').'><td>'.$item['keyword'].'</td><td>'.$item['name'].'</td><td>'.($item['exist']?'是':'否').'</td></tr>';
			if($item['exist'])
			{
				echo '<tr><td>'.$item['keyword'].'</td><td>'.$item['name'].'</td></tr>';
			}
		}
		echo '</tbody></table>';
	}
}