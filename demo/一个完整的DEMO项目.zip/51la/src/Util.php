<?php
class Util{
	/**
	 * 匹配出字符串中的所有URL
	 * @param  string $str 
	 * @return array      
	 */
	public static function getAllURL($str)
	{
		$reg = '/http:\/\/[^\s]+/i';
		$arr = array();
		if(preg_match_all($reg, $str, $rarr))
		{
			$arr = $rarr[0];
		}
		return $arr;
	}
	/**
	 * 在字符串里面搜索数组里面的值
	 * @param  array $arr 
	 * @param  string $str 
	 * @return bool      
	 */
	public static function arrayInStr($arr,$str)
	{
		foreach ($arr as $item) {
			if(preg_match('/'.$item.'/i', $str))
			{
				
				return 1;
			}
		}
		return 0;
	}
	/**
	 * 解析url参数
	 * @param  string $url 
	 * @return array      参数关联数组
	 */
	public static function parseURLQuery($url)
	{
		$arr = array();
		$parr = explode('?',$url);
		$parr = isset($parr[1])?$parr:explode(';', $url);
		if(!isset($parr[1]))return $arr;
		$pqarr = explode('&', $parr[1]);
		foreach ($pqarr as $v) {
			if($v)
			{
				$t = explode('=', $v);
				$arr[$t[0]] = isset($t[1])?$t[1]:'';
			}
		}
		return $arr;
	}
	/**
	 * 编码转换
	 * @param  string $string      
	 * @param  string $outEncoding 
	 * @return string              
	 */
	public static function safeEncoding($string,$outEncoding ='UTF-8')      
	{      
	    $encoding = "UTF-8";      
	    for($i=0;$i<strlen($string);$i++)      
	    {      
	        if(ord($string{$i})<128)      
	            continue;      
	          
	        if((ord($string{$i})&224)==224)      
	        {      
	            //第一个字节判断通过      
	            $char = $string{++$i};      
	            if((ord($char)&128)==128)      
	            {      
	                //第二个字节判断通过      
	                $char = $string{++$i};      
	                if((ord($char)&128)==128)      
	                {      
	                    $encoding = "UTF-8";      
	                    break;      
	                }      
	            }      
	        }      
	      
	        if((ord($string{$i})&192)==192)      
	        {      
	            //第一个字节判断通过      
	            $char = $string{++$i};      
	            if((ord($char)&128)==128)      
	            {      
	                // 第二个字节判断通过      
	                $encoding = "GB2312";      
	                break;      
	            }      
	        }      
	    }      
	               
	    if(strtoupper($encoding) == strtoupper($outEncoding))      
	        return $string;      
	    else     
	        return iconv($encoding,$outEncoding,$string);      
	}  
}