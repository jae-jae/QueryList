<?php
/**
 * Created by SublimeText2.
 * User:JAE
 * Date: 2014-3-18
 * Blog:http://blog.jaekj.com
 * QQ:734708094
 * 根据51la数据，查询关键字排名
 * 版本:V3.1
 */
function __autoload($filename)
{
	$file = 'src/'.$filename.'.php';
	if(is_file($file))
	{
		include $file;
		return true;
	}
	return false;
}

if(!count($_POST))die();
$type = $_POST['type'];
if($type=='getAllURL')
{
	$rules = str_replace("~","\r\n", $_POST['rules']);
	file_put_contents('rules.txt', $rules);
	$config = "<?php return array('id'=>'".$_POST['id']."','password'=>'".$_POST['pwd']."','rule'=>file('rules.txt'));";
	file_put_contents('config.php', $config);
	$hj = new Login();
	$arr = $hj->getTxt();
	echo json_encode($arr);
}elseif ($type=='getInfo') {
	$arr = Search::checkOne($_POST['url']);
	echo json_encode($arr);
}



